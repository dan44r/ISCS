	function ReturnToChooser(){
	  document.frmReturn.submit();
	}
// ------------------------------------------------------------------------

	 function CheckInteger(p){
		var checkOK = "0123456789";
		var checkStr = p;
		var allValid = true;
		for (i = 0;  i < checkStr.length;  i++){
		  ch = checkStr.charAt(i);
		  for (j = 0;  j < checkOK.length;  j++)
			 if (ch == checkOK.charAt(j)) break;
		  if (j == checkOK.length){
			 allValid = false;
			 break;
		  }
		}
		if (!allValid){
		
			alert('Please enter numbers only in the Qty columns');
		
		  return false;
		}
		else{
		  return true;
		}
	 }


	 function CheckDbl(p){
		var checkOK = ".0123456789";
		var checkStr = p;
		var allValid = true;
		for (i = 0;  i < checkStr.length;  i++){
		  ch = checkStr.charAt(i);
		  for (j = 0;  j < checkOK.length;  j++)
			 if (ch == checkOK.charAt(j)) break;
		  if (j == checkOK.length){
			 allValid = false;
			 break;
		  }
		}
		if (!allValid){
		
			alert('Please enter numeric values only in the length width and height columns');
		
		  return false;
		}
		else{
		  return true;
		}
	 }

	 function CheckCur(p){
		var checkOK = "$.0123456789";
		var checkStr = p;
		var allValid = true;
		for (i = 0;  i < checkStr.length;  i++){
		  ch = checkStr.charAt(i);
		  for (j = 0;  j < checkOK.length;  j++)
			 if (ch == checkOK.charAt(j)) break;
		  if (j == checkOK.length){
			 allValid = false;
			 break;
		  }
		}
		if (!allValid){
		
			alert('Please enter US currency values only in the Shipment Charges columns');
		
		  return false;
		}
		else{
		  return true;
		}
	 }


// ------------------------------------------------------------------------
// SaveChanges Button on pickup request form calls this function
// Validates ship from and ship to locations
// This only gets called when a brand new pick up request is first saved.
// ------------------------------------------------------------------------

	function SaveChanges(f,jsStatus,jsTbill,jsDateIn,jsUserCode) {
	
		//We need to set this hidden field so a new Tbill record is created
		//Normally this field defaults to 0.  Only if we are going from
		//Pending to Setup do we create a TBill record.

		f.CreateTBill.value=jsTbill;

		var jsValue = "";
		var msg     = "";

		f.StatusCode.value      = jsStatus;
		f.ShipFromState.value   = f.ShipFromStateId.options[f.ShipFromStateId.selectedIndex].value;
		f.ShipFromCountry.value = f.ShipFromCountryId.options[f.ShipFromCountryId.selectedIndex].value;

		// ------------------------------------------------------------------------
		// Validate Pickup Location Ship From Company
		// ------------------------------------------------------------------------
		if (trim(f.ShipFromCompany.value) == ''){
			alert('Please enter a value for Ship From Company.');
			window.location.hash = "#FormTop";
			f.ShipFromCompany.focus();
			return;
		}

		// ------------------------------------------------------------------------
		// Validate Pickup Location ExportEIN
		// ------------------------------------------------------------------------
		if (trim(f.ExportEIN.value) == ''){
			alert('Please enter a value for Exporter\'s EIN (IRS) No.');
			window.location.hash = "#FormTop";
			f.ExportEIN.focus();
			return;
		}


		// ------------------------------------------------------------------------
		// Validate Pickup Location Address
		// ------------------------------------------------------------------------
		if (trim(f.ShipFromAddress.value) == ''){
			alert('Please enter a value for Pickup Location Address.');
			window.location.hash = "#FormTop";
			f.ShipFromAddress.focus();
			return;
		}

		// ------------------------------------------------------------------------
		// Validate Pickup Location City
		// ------------------------------------------------------------------------
		if (trim(f.ShipFromCity.value) == ''){
			alert('Please enter a value for Pickup Location City.');
			window.location.hash = "#FormTop";
			f.ShipFromCity.focus();
			return;
		}

		// ------------------------------------------------------------------------
		// Validate Pickup Location State
		// ------------------------------------------------------------------------
		if (f.ShipFromStateId.selectedIndex == 0){
			alert('Please choose a value for Pickup Location State.');
			window.location.hash = "#FormTop";
			f.ShipFromStateId.focus();
			return;
		}

		// ------------------------------------------------------------------------
		// Validate Pickup Location Postal Code
		// ------------------------------------------------------------------------
		if (trim(f.ShipFromPostalCode.value) == ''){
			alert('Please enter a value for Pickup Location Postal Code.');
			window.location.hash = "#FormTop";
			f.ShipFromPostalCode.focus();
			return;
		}

		// ------------------------------------------------------------------------
		// Validate Pickup Location Contact
		// ------------------------------------------------------------------------
		if (trim(f.ShipFromContact.value) == ''){
			alert('Please enter a value for Pickup Location Contact.');
			window.location.hash = "#FormTop";
			f.ShipFromContact.focus();
			return;
		}

		// ------------------------------------------------------------------------
		// Validate Pickup Location Phone No.
		// ------------------------------------------------------------------------
		if (trim(f.ShipFromPhone.value) == ''){
			alert('Please enter a value for Pickup Location Phone No.');
			window.location.hash = "#FormTop";
			f.ShipFromPhone.focus();
			return;
		}

		// ------------------------------------------------------------------------
		// Validate Pickup Location Email Address
		// ------------------------------------------------------------------------
		if (!isValidEmail(f.ShipFromEmail.value)){
			alert('Please enter a value for Pickup Location Email Address.');
			window.location.hash = "#FormTop";
			f.ShipFromEmail.focus();
			return;
		}

		// ------------------------------------------------------------------------
		// Validate Pickup Location Pickup Date
		// ------------------------------------------------------------------------


		var jsToday = new Date(jsDateIn);

		if (!isDate(f.ShipFromDate.value)){
			alert('Please enter a value for Pickup Location Pickup Date.');
			window.location.hash = "#FormTop";
			f.ShipFromDate.focus();
			return;
		}


		var jsPickupDate = new Date(f.ShipFromDate.value);

	//If GLS Employee ignore this validation.
	//Allows editing a pickup request with a pick up date in the past.
		if (jsUserCode > 1000){
				if (Date.parse(jsToday) > Date.parse(jsPickupDate)){
					msg = "";
					msg = msg + "The Pickup Location Pickup Date you selected is invalid.         \n";
					msg = msg + "Please choose a different Pickup Location Pickup Date.";
					alert(msg);
					window.location.hash = "#FormTop";
					f.ShipFromDate.focus();
					return;
				}
		}
		// ------------------------------------------------------------------------
		// Validate Pickup Location Ready Time
		// ------------------------------------------------------------------------
		if (f.ShipFromTimeReady.selectedIndex == 0){
			alert('Please choose a value for Pickup Location Ready Time.');
			window.location.hash = "#FormTop";
			f.ShipFromTimeReady.focus();
			return;
		}

		// ------------------------------------------------------------------------
		// Validate Pickup Location Latest Pickup
		// ------------------------------------------------------------------------
		if (f.ShipFromTimeNLT.selectedIndex == 0){
			alert('Please choose a value for Pickup Location Latest Pickup.');
			window.location.hash = "#FormTop";
			f.ShipFromTimeNLT.focus();
			return;
		}

		if (f.ShipFromTimeReady.selectedIndex >= f.ShipFromTimeNLT.selectedIndex){
			msg = "";
			msg = msg + "The Pickup Location Latest Pickup must come after the           \n";
			msg = msg + "Pickup Location Ready Time.                                   \n\n";
			msg = msg + "Please choose a different Pickup Location Latest Pickup.";
			alert(msg);
			window.location.hash = "#FormTop";
			f.ShipFromTimeNLT.focus();
			return;
		}

		// ------------------------------------------------------------------------
		// Validate Delivery Location Ship To Company
		// ------------------------------------------------------------------------
		if (trim(f.ShipToCompany.value) == ''){
			alert('Please enter a value for Delivery Location Ship To Company.');
			window.location.hash = "#FormTop";
			f.ShipToCompany.focus();
			return;
		}

		// ------------------------------------------------------------------------
		// Validate Delivery Location Delivery Date
		// ------------------------------------------------------------------------
		if (!isDate(f.ShipToDate.value)){
			alert('Please enter a value for Delivery Location Delivery Date.');
			window.location.hash = "#FormTop";
			f.ShipToDate.focus();
			return;
		}

		var jsDeliveryDate = new Date(f.ShipToDate.value);
		if (Date.parse(jsPickupDate) > Date.parse(jsDeliveryDate)){
			msg = "";
			msg = msg + "The Delivery Location Delivery Date you selected is invalid.            \n";
			msg = msg + "Please choose a Delivery Location Delivery Date that is on              \n";
			msg = msg + "or after the Pickup Location Pickup Date.";
			alert(msg);
			window.location.hash = "#FormTop";
			f.ShipToDate.focus();
			return;
		}

		// ------------------------------------------------------------------------
		// Validate Delivery Location Address
		// ------------------------------------------------------------------------
		if (trim(f.ShipToAddress.value) == ''){
			alert('Please enter a value for Delivery Location Address.');
			window.location.hash = "#FormTop";
			f.ShipToAddress.focus();
			return;
		}

		// ------------------------------------------------------------------------
		// Validate Delivery Location City
		// ------------------------------------------------------------------------
		if (trim(f.ShipToCity.value) == ''){
			alert('Please enter a value for Delivery Location City.');
			window.location.hash = "#FormTop";
			f.ShipToCity.focus();
			return;
		}


		// ------------------------------------------------------------------------
		// Validate Delivery Location Postal Code
		// ------------------------------------------------------------------------
		if (trim(f.ShipToPostalCode.value) == ''){
			alert('Please enter a value for Delivery Location Postal Code.');
			window.location.hash = "#FormTop";
			f.ShipToPostalCode.focus();
			return;
		}


		// ------------------------------------------------------------------------
		// Validate Delivery Location Contact
		// ------------------------------------------------------------------------
		if (trim(f.ShipToContact.value) == ''){
			alert('Please enter a value for Delivery Location Contact.');
			window.location.hash = "#FormTop";
			f.ShipToContact.focus();
			return;
		}

		// ------------------------------------------------------------------------
		// Validate Delivery Location Phone No.
		// ------------------------------------------------------------------------
		if (trim(f.ShipToPhone.value) == ''){
			alert('Please enter a value for Delivery Location Phone No.');
			window.location.hash = "#FormTop";
			f.ShipToPhone.focus();
			return;
		}

		//-------------------------------------------------------------------------
		//-------------------------------------------------------------------------
		//-------------------------------------------------------------------------
		// If this is not a GLS Employee then this ends the validation.
		// The form may be submitted.
		//-------------------------------------------------------------------------
		//-------------------------------------------------------------------------
		//-------------------------------------------------------------------------
		f.Submitted.value = "1";
		f.submit();
	}


	function SelectLocation(n){
		var f = document.frmAddEdit;
		var parm1 = "?DataType=" + n;
		var parm2 = ""
		var parm3 = "";
		var parms = "UserLocationPop.asp" + parm1
		var WinAttr = "resizable=yes,scrollbars,menubar=no,toolbars=no,width=420,height=500 top=2";
		var win1 =window.open(parms,"GetLocation",WinAttr);
		win1.focus();
	}

	function SelectLocationI(n){
		var f = document.frmAddEdit;
		var parm1 = "?DataType=" + n;
		var parm2 = ""
		var parm3 = "";
		var parms = "UserLocationPopI.asp" + parm1
		var WinAttr = "resizable=yes,scrollbars,menubar=no,toolbars=no,width=420,height=500 top=2";
		//var WinAttr = "status=yes,resizable=yes,scrollbars,menubar=yes,toolbars=yes,width=420,height=500 top=2";
		var win1 =window.open(parms,"GetLocation",WinAttr);
		win1.focus();
	}

	// ------------------------------------------------------------------------
	// Get Warehouse Locations
	// ------------------------------------------------------------------------

	function SelectWarehouseLocation(n,jsPickupRequestType,jsPickupRequestTypeWarehouse){
		var f = document.frmAddEdit;
		var parm1 = "?DataType=" + n;
		var parm2 = "&amp;PickupRequestType=" + jsPickupRequestType;
		var parm3 = "&amp;PickupRequestTypeWarehouse=" + jsPickupRequestTypeWarehouse;
		var parms = "UserLocationWarehousePop.asp" + parm1 + parm2 + parm3
		var WinAttr = "resizable=yes,scrollbars,menubar=no,toolbars=no,width=420,height=500 top=2";
		//var win1 =window.open(parms,"GetLocation");
		var win1 =window.open(parms,"GetLocation",WinAttr);
		win1.focus();
	}

