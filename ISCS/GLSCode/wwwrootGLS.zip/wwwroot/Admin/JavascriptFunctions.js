	function ReturnToChooser(){
	  document.frmReturn.submit();
	}
// ------------------------------------------------------------------------

	 function CheckInteger(p){
		var checkOK = "0123456789";
		var checkStr = p;
		var allValid = true;
		for (i = 0;  i < checkStr.length;  i++){
		  ch = checkStr.charAt(i);
		  for (j = 0;  j < checkOK.length;  j++)
			 if (ch == checkOK.charAt(j)) break;
		  if (j == checkOK.length){
			 allValid = false;
			 break;
		  }
		}
		if (!allValid){
		
			alert('Please enter numbers only in the Qty columns');
		
		  return false;
		}
		else{
		  return true;
		}
	 }


	 function CheckDbl(p){
		var checkOK = ".0123456789";
		var checkStr = p;
		var allValid = true;
		for (i = 0;  i < checkStr.length;  i++){
		  ch = checkStr.charAt(i);
		  for (j = 0;  j < checkOK.length;  j++)
			 if (ch == checkOK.charAt(j)) break;
		  if (j == checkOK.length){
			 allValid = false;
			 break;
		  }
		}
		if (!allValid){
		
			alert('Please enter numeric values only in the length width and height columns');
		
		  return false;
		}
		else{
		  return true;
		}
	 }

	 function CheckCur(p){
		var checkOK = "$.0123456789";
		var checkStr = p;
		var allValid = true;
		for (i = 0;  i < checkStr.length;  i++){
		  ch = checkStr.charAt(i);
		  for (j = 0;  j < checkOK.length;  j++)
			 if (ch == checkOK.charAt(j)) break;
		  if (j == checkOK.length){
			 allValid = false;
			 break;
		  }
		}
		if (!allValid){
		
			alert('Please enter US currency values only in the Shipment Charges columns');
		
		  return false;
		}
		else{
		  return true;
		}
	 }

// ------------------------------------------------------------------------
	function SaveChanges(f,jsStatus,jsTbill,jsDateIn,jsUserCode) {
	
		//We need to set this hidden field so a new Tbill record is created
		//Normally this field defaults to 0.  Only if we are going from
		//Pending to Setup do we create a TBill record.

		f.CreateTBill.value=jsTbill;

		var jsValue = "";
		var msg     = "";
		f.StatusCode.value      = jsStatus;
		f.ShipToState.value   	= f.ShipToStateId.options[f.ShipToStateId.selectedIndex].value;
		f.ShipFromState.value   = f.ShipFromStateId.options[f.ShipFromStateId.selectedIndex].value;
		f.ShipFromCountry.value = f.ShipFromCountryId.options[f.ShipFromCountryId.selectedIndex].value;


		// ------------------------------------------------------------------------
		// Validate CheckForDimensions First here
		// Otherwise the user will have to re-type Ship From To Info.
		// ------------------------------------------------------------------------

		jsValue = trim(f.CheckForDimensions.value);
		if (jsValue == '' || jsValue == 0){
			alert('You must provide handling unit Dimesnions before continuing. \n Please edit the handling unit on this page that has NO Dimensions.');
			window.location.hash = "#skids";
			return;
		}


		// ------------------------------------------------------------------------
		// Validate Pickup Location Ship From Company
		// ------------------------------------------------------------------------
		if (trim(f.ShipFromCompany.value) == ''){
			alert('Please enter a value for Ship From Company.');
			window.location.hash = "#FormTop";
			f.ShipFromCompany.focus();
			return;
		}

		// ------------------------------------------------------------------------
		// Validate Pickup Location Address
		// ------------------------------------------------------------------------
		if (trim(f.ShipFromAddress.value) == ''){
			alert('Please enter a value for Pickup Location Address.');
			window.location.hash = "#FormTop";
			f.ShipFromAddress.focus();
			return;
		}

		// ------------------------------------------------------------------------
		// Validate Pickup Location City
		// ------------------------------------------------------------------------
		if (trim(f.ShipFromCity.value) == ''){
			alert('Please enter a value for Pickup Location City.');
			window.location.hash = "#FormTop";
			f.ShipFromCity.focus();
			return;
		}

		// ------------------------------------------------------------------------
		// Validate Pickup Location State
		// ------------------------------------------------------------------------
		if (f.ShipFromStateId.selectedIndex == 0){
			alert('Please choose a value for Pickup Location State.');
			window.location.hash = "#FormTop";
			f.ShipFromStateId.focus();
			return;
		}

		// ------------------------------------------------------------------------
		// Validate Pickup Location Postal Code
		// ------------------------------------------------------------------------
		if (trim(f.ShipFromPostalCode.value) == ''){
			alert('Please enter a value for Pickup Location Postal Code.');
			window.location.hash = "#FormTop";
			f.ShipFromPostalCode.focus();
			return;
		}

		// ------------------------------------------------------------------------
		// Validate Pickup Location Contact
		// ------------------------------------------------------------------------
		if (trim(f.ShipFromContact.value) == ''){
			alert('Please enter a value for Pickup Location Contact.');
			window.location.hash = "#FormTop";
			f.ShipFromContact.focus();
			return;
		}

		// ------------------------------------------------------------------------
		// Validate Pickup Location Phone No.
		// ------------------------------------------------------------------------
		if (trim(f.ShipFromPhone.value) == ''){
			alert('Please enter a value for Pickup Location Phone No.');
			window.location.hash = "#FormTop";
			f.ShipFromPhone.focus();
			return;
		}

		// ------------------------------------------------------------------------
		// Validate Pickup Location Email Address
		// ------------------------------------------------------------------------
		if (!isValidEmail(f.ShipFromEmail.value)){
			alert('Please enter a value for Pickup Location Email Address.');
			window.location.hash = "#FormTop";
			f.ShipFromEmail.focus();
			return;
		}

		// ------------------------------------------------------------------------
		// Validate Pickup Location Pickup Date
		// ------------------------------------------------------------------------


		var jsToday = new Date(jsDateIn);

		if (!isDate(f.ShipFromDate.value)){
			alert('Please enter a value for Pickup Location Pickup Date.');
			window.location.hash = "#FormTop";
			f.ShipFromDate.focus();
			return;
		}

		var jsPickupDate = new Date(f.ShipFromDate.value);

	//If GLS Employee ignore this validation.
	//Allows editing a pickup request with a pick up date in the past.
		if (jsUserCode > 1000){
				if (Date.parse(jsToday) > Date.parse(jsPickupDate)){
					msg = "";
					msg = msg + "The Pickup Location Pickup Date you selected is invalid.         \n";
					msg = msg + "Please choose a different Pickup Location Pickup Date.";
					alert(msg);
					window.location.hash = "#FormTop";
					f.ShipFromDate.focus();
					return;
				}
		}
		// ------------------------------------------------------------------------
		// Validate Pickup Location Ready Time
		// ------------------------------------------------------------------------
		if (f.ShipFromTimeReady.selectedIndex == 0){
			alert('Please choose a value for Pickup Location Ready Time.');
			window.location.hash = "#FormTop";
			f.ShipFromTimeReady.focus();
			return;
		}

		// ------------------------------------------------------------------------
		// Validate Pickup Location Latest Pickup
		// ------------------------------------------------------------------------
		if (f.ShipFromTimeNLT.selectedIndex == 0){
			alert('Please choose a value for Pickup Location Latest Pickup.');
			window.location.hash = "#FormTop";
			f.ShipFromTimeNLT.focus();
			return;
		}

		if (f.ShipFromTimeReady.selectedIndex >= f.ShipFromTimeNLT.selectedIndex){
			msg = "";
			msg = msg + "The Pickup Location Latest Pickup must come after the           \n";
			msg = msg + "Pickup Location Ready Time.                                   \n\n";
			msg = msg + "Please choose a different Pickup Location Latest Pickup.";
			alert(msg);
			window.location.hash = "#FormTop";
			f.ShipFromTimeNLT.focus();
			return;
		}

		// ------------------------------------------------------------------------
		// Validate Delivery Location Ship To Company
		// ------------------------------------------------------------------------
		if (trim(f.ShipToCompany.value) == ''){
			alert('Please enter a value for Delivery Location Ship To Company.');
			window.location.hash = "#FormTop";
			f.ShipToCompany.focus();
			return;
		}

		// ------------------------------------------------------------------------
		// Validate Delivery Location Delivery Date
		// ------------------------------------------------------------------------
		if (!isDate(f.ShipToDate.value)){
			alert('Please enter a value for Delivery Location Delivery Date.');
			window.location.hash = "#FormTop";
			f.ShipToDate.focus();
			return;
		}

		var jsDeliveryDate = new Date(f.ShipToDate.value);
		if (Date.parse(jsPickupDate) > Date.parse(jsDeliveryDate)){
			msg = "";
			msg = msg + "The Delivery Location Delivery Date you selected is invalid.            \n";
			msg = msg + "Please choose a Delivery Location Delivery Date that is on              \n";
			msg = msg + "or after the Pickup Location Pickup Date.";
			alert(msg);
			window.location.hash = "#FormTop";
			f.ShipToDate.focus();
			return;
		}

		// ------------------------------------------------------------------------
		// Validate Delivery Location Address
		// ------------------------------------------------------------------------
		if (trim(f.ShipToAddress.value) == ''){
			alert('Please enter a value for Delivery Location Address.');
			window.location.hash = "#FormTop";
			f.ShipToAddress.focus();
			return;
		}

		// ------------------------------------------------------------------------
		// Validate Delivery Location City
		// ------------------------------------------------------------------------
		if (trim(f.ShipToCity.value) == ''){
			alert('Please enter a value for Delivery Location City.');
			window.location.hash = "#FormTop";
			f.ShipToCity.focus();
			return;
		}

		// ------------------------------------------------------------------------
		// Validate Delivery Location State
		// ------------------------------------------------------------------------
		if (f.ShipToStateId.selectedIndex == 0){
			alert('Please choose a value for Delivery Location State.');
			window.location.hash = "#FormTop";
			f.ShipToStateId.focus();
			return;
		}

		// ------------------------------------------------------------------------
		// Validate Delivery Location Postal Code
		// ------------------------------------------------------------------------
		if (trim(f.ShipToPostalCode.value) == ''){
			alert('Please enter a value for Delivery Location Postal Code.');
			window.location.hash = "#FormTop";
			f.ShipToPostalCode.focus();
			return;
		}


		// ------------------------------------------------------------------------
		// Validate Delivery Location Contact
		// ------------------------------------------------------------------------
		if (trim(f.ShipToContact.value) == ''){
			alert('Please enter a value for Delivery Location Contact.');
			window.location.hash = "#FormTop";
			f.ShipToContact.focus();
			return;
		}

		// ------------------------------------------------------------------------
		// Validate Delivery Location Phone No.
		// ------------------------------------------------------------------------
		if (trim(f.ShipToPhone.value) == ''){
			alert('Please enter a value for Delivery Location Phone No.');
			window.location.hash = "#FormTop";
			f.ShipToPhone.focus();
			return;
		}


		// ------------------------------------------------------------------------
		// Validate That we have at least one skid and skid item
		// Also validate we have a package type and Dimensions.
		// ------------------------------------------------------------------------
		jsValue = trim(f.CheckForSkids.value);
		if (jsValue == '' || jsValue == 0){
			alert('You must add a handling unit and shipment items before continuing.');
			window.location.hash = "#skids";
			return;
		}

		jsValue = trim(f.PackageTypeCheck.value);
		if (jsValue == '' || jsValue == 0){
			alert('You must select a handling unit type for each unit before continuing.');
			window.location.hash = "#skids";
			return;
		}


		jsValue = trim(f.CheckForDimensions.value);
		if (jsValue == '' || jsValue == 0){
			alert('You must provide handling unit Dimesnions before continuing. \n Please edit the handling unit on this page that has NO Dimensions.');
			window.location.hash = "#skids";
			return;
		}

		jsValue = trim(f.CheckForShipmentItems.value);
		if (jsValue == '' || jsValue == 0){
			alert('You must add a handling unit and shipment items before continuing.');
			window.location.hash = "#skids";
			return;
		}


		// ------------------------------------------------------------------------
		// Validate Mode of Transportation
		// ------------------------------------------------------------------------
		var msg = "";
		var jsTModeChecked = false;

		for(var i=0; i<f.TMode.length; i++){
			if(f.TMode[i].checked){
				jsTModeChecked = true;
			}
		}

		if (!jsTModeChecked){
			msg = "";
			msg = msg + "Please chose on of the Modes of Transportation. If you are unsure              \n";
			msg = msg + "which mode is best for you select GLSAdvantage. GLSAdvantage                   \n";
			msg = msg + "ensures you will receive the most cost effective method available.             \n";
			alert(msg);
			window.location.hash = "RS";
			f.TMode[2].focus();
			return;
		}
	
	
if (jsUserCode == 1000){	
//		If this is a GLS Employee then they need to choose another
//		Mode of transportation other than GLS Advantage.
		var TransModeVal = f.TransMode.value	;
	
		//alert(TransModeVal);

		if (TransModeVal == 0){
			msg = "";
			msg = msg + "Please choose one of the Modes of Transportation other than GLS Advantage. 			\n";
			alert(msg);
			window.location.hash = "RS";
			f.TMode[2].focus();
			return;
		}
		
}// End If UserCode = 1000

		var jsData = "";
		jsData = f.TransMode.value;
		switch(jsData * 1) {
			case 1:
				f.TransModeService1.value = f.TMode1Service1.options[f.TMode1Service1.selectedIndex].value;
				break;
			case 2:
				f.TransModeService1.value = f.TMode2Service1.options[f.TMode2Service1.selectedIndex].value;
				break;
			default: //(acts like else)
				f.TransModeService1.value = " ";
				break;
		}

		//-------------------------------------------------------------------------
		//-------------------------------------------------------------------------
		//-------------------------------------------------------------------------
		// If this is not a GLS Employee then this ends the validation.
		// The form may be submitted.
		//-------------------------------------------------------------------------
		//-------------------------------------------------------------------------
		//-------------------------------------------------------------------------

if (jsUserCode > 1000){	
				f.Submitted.value = "2";
				f.submit();
				return;
} // jsUserCode > 1000  

//Debug
//alert(jsStatus.toUpperCase());
//alert(f.GLSAccountId.selectedIndex);
//alert(f.GLSAccountIdDropDown.selectedIndex);

		// ------------------------------------------------------------------------
		// Validate GLSAccountId
		// ------------------------------------------------------------------------
		if (jsStatus.toUpperCase() == "PND"){
			if (f.GLSAccountIdDropDown.selectedIndex ==0){
				msg = "";
				msg = msg + "The Account Code you selected is invalid.               \n";
				msg = msg + "Please choose a different Account Code.";
				alert(msg);
				window.location.hash = "#GLSShipmentInfo";
				f.GLSAccountIdDropDown.focus();
				return;
			}
		}

		// ------------------------------------------------------------------------
		// Validate GLS Only Information When "Accept" is Clicked
		// ------------------------------------------------------------------------
		if (jsStatus.toUpperCase() == "SUP"){
		// ------------------------------------------------------------------------
		// Validate GLSAccountId
		// ------------------------------------------------------------------------
		// We check the hidden field value here since the drop down is disabled.

//			jsValue = f.GLSAccountId.value;
//			if (jsValue =='0'){
//				msg = "";
//				msg = msg + "The Account Code you selected is invalid.               \n";
//				msg = msg + "Please choose a different Account Code.";
//				alert(msg);
//				window.location.hash = "#GLSShipmentInfo";
//				return;
//			}


			if (f.GLSAccountIdDropDown.selectedIndex ==0){
				msg = "";
				msg = msg + "The Account Code you selected is invalid.               \n";
				msg = msg + "Please choose a different Account Code.";
				alert(msg);
				window.location.hash = "#GLSShipmentInfo";
				f.GLSAccountIdDropDown.focus();
				return;
			}



			// ------------------------------------------------------------------------
			// Validate GLSCarrierName
			// ------------------------------------------------------------------------
			
			jsValue = f.GLSCarrierName.value;
			if (trim(jsValue) == ''){
				alert('Please enter a value for the Shipment Information Carrier Name.');
				window.location.hash = "#GLSShipmentInfo";
				f.GLSCarrierName.focus();
				return;
			}

//Start Added Validation 01152004
			// ------------------------------------------------------------------------
			// Validate GLSBuyRateTransportCharge
			// ------------------------------------------------------------------------
			jsValue = f.GLSBuyRateTransportCharge.value;

			if (trim(jsValue) != ''){

				if (!CheckCur(jsValue)){
					window.location.hash = "#GLSShipmentCharges";
					f.GLSBuyRateTransportCharge.focus();
					return;
				}
			}

//Added 12-23-2004 for additional carriers
			jsValue = f.GLSBuyRateTransportChargeInterm.value;
			if (trim(jsValue) != ''){

				if (!CheckCur(jsValue)){
					window.location.hash = "#GLSShipmentCharges";
					f.GLSBuyRateTransportChargeInterm.focus();
					return;
				}
			}

			jsValue = f.GLSBuyRateTransportChargeDelivery.value;
			if (trim(jsValue) != ''){

				if (!CheckCur(jsValue)){
					window.location.hash = "#GLSShipmentCharges";
					f.GLSBuyRateTransportChargeDelivery.focus();
					return;
				}
			}

			jsValue = f.GLSBuyRateTransportChargeDelivery.value;
			if (trim(jsValue) != ''){

				if (!CheckCur(jsValue)){
					window.location.hash = "#GLSShipmentCharges";
					f.GLSBuyRateTransportChargeDelivery.focus();
					return;
				}
			}

			jsValue = f.GLSBuyRateTransportChargeOther.value;
			if (trim(jsValue) != ''){

				if (!CheckCur(jsValue)){
					window.location.hash = "#GLSShipmentCharges";
					f.GLSBuyRateTransportChargeOther.focus();
					return;
				}
			}

			jsValue = f.GLSBuyRateAccessorialChargeInterm.value;
			if (trim(jsValue) != ''){

				if (!CheckCur(jsValue)){
					window.location.hash = "#GLSShipmentCharges";
					f.GLSBuyRateAccessorialChargeInterm.focus();
					return;
				}
			}

			jsValue = f.GLSBuyRateAccessorialChargeDelivery.value;
			if (trim(jsValue) != ''){

				if (!CheckCur(jsValue)){
					window.location.hash = "#GLSShipmentCharges";
					f.GLSBuyRateAccessorialChargeDelivery.focus();
					return;
				}
			}

			jsValue = f.GLSBuyRateAccessorialChargeOther.value;
			if (trim(jsValue) != ''){

				if (!CheckCur(jsValue)){
					window.location.hash = "#GLSShipmentCharges";
					f.GLSBuyRateAccessorialChargeOther.focus();
					return;
				}
			}

			jsValue = f.GLSBuyRateFuelChargeInterm.value;
			if (trim(jsValue) != ''){

				if (!CheckCur(jsValue)){
					window.location.hash = "#GLSShipmentCharges";
					f.GLSBuyRateFuelChargeInterm.focus();
					return;
				}
			}

			jsValue = f.GLSBuyRateFuelChargeDelivery.value;
			if (trim(jsValue) != ''){

				if (!CheckCur(jsValue)){
					window.location.hash = "#GLSShipmentCharges";
					f.GLSBuyRateFuelChargeDelivery.focus();
					return;
				}
			}

			jsValue = f.GLSBuyRateFuelChargeOther.value;
			if (trim(jsValue) != ''){
				if (!CheckCur(jsValue)){
					window.location.hash = "#GLSShipmentCharges";
					f.GLSBuyRateFuelChargeOther.focus();
					return;
				}
			}

//END validation for additional carriers
			// ------------------------------------------------------------------------
			// Validate GLSSellRateTransportCharge
			// ------------------------------------------------------------------------
			jsValue = f.GLSSellRateTransportCharge.value;

			if (trim(jsValue) != ''){

				if (!CheckCur(jsValue)){
					window.location.hash = "#GLSShipmentCharges";
					f.GLSSellRateTransportCharge.focus();
					return;
				}
			}

			// ------------------------------------------------------------------------
			// Validate GLSBuyRateAccessorialCharge
			// ------------------------------------------------------------------------
			jsValue = f.GLSBuyRateAccessorialCharge.value;

			if (trim(jsValue) != ''){

				if (!CheckCur(jsValue)){
					window.location.hash = "#GLSShipmentCharges";
					f.GLSBuyRateAccessorialCharge.focus();
					return;
				}
			}

			// ------------------------------------------------------------------------
			// Validate GLSSellRateAccessorialCharge
			// ------------------------------------------------------------------------
			jsValue = f.GLSSellRateAccessorialCharge.value;

			if (trim(jsValue) != ''){

				if (!CheckCur(jsValue)){
					window.location.hash = "#GLSShipmentCharges";
					f.GLSSellRateAccessorialCharge.focus();
					return;
				}
			}

			// ------------------------------------------------------------------------
			// Validate GLSSellRateFuelCharge
			// ------------------------------------------------------------------------
			jsValue = f.GLSSellRateFuelCharge.value;

			if (trim(jsValue) != ''){

				if (!CheckCur(jsValue)){
					window.location.hash = "#GLSShipmentCharges";
					f.GLSSellRateFuelCharge.focus();
					return;
				}
			}


			// ------------------------------------------------------------------------
			// Validate GLSBuyRateFuelCharge
			// ------------------------------------------------------------------------
			jsValue = f.GLSBuyRateFuelCharge.value;

			if (trim(jsValue) != ''){

				if (!CheckCur(jsValue)){
					window.location.hash = "#GLSShipmentCharges";
					f.GLSBuyRateFuelCharge.focus();
					return;
				}
			}

			// ------------------------------------------------------------------------
			// Validate GLSSellRateFuelCharge
			// ------------------------------------------------------------------------
			jsValue = f.GLSSellRateFuelCharge.value;

			if (trim(jsValue) != ''){

				if (!CheckCur(jsValue)){
					window.location.hash = "#GLSShipmentCharges";
					f.GLSSellRateFuelCharge.focus();
					return;
				}
			}


			// ------------------------------------------------------------------------
			// Validate GLSBuyRateInsuraceCharge
			// ------------------------------------------------------------------------
			jsValue = f.GLSBuyRateInsuraceCharge.value;

			if (trim(jsValue) != ''){

				if (!CheckCur(jsValue)){
					window.location.hash = "#GLSShipmentCharges";
					f.GLSBuyRateInsuraceCharge.focus();
					return;
				}
			}

			// ------------------------------------------------------------------------
			// Validate GLSSellRateInsuraceCharge
			// ------------------------------------------------------------------------
			jsValue = f.GLSSellRateInsuraceCharge.value;

			if (trim(jsValue) != ''){

				if (!CheckCur(jsValue)){
					window.location.hash = "#GLSShipmentCharges";
					f.GLSSellRateInsuraceCharge.focus();
					return;
				}
			}

			// ------------------------------------------------------------------------
			// Validate GLSBuyRateCodFee
			// ------------------------------------------------------------------------
			jsValue = f.GLSBuyRateCodFee.value;

			if (trim(jsValue) != ''){

				if (!CheckCur(jsValue)){
					window.location.hash = "#GLSShipmentCharges";
					f.GLSBuyRateCodFee.focus();
					return;
				}
			}

			// ------------------------------------------------------------------------
			// Validate GLSSellRateCodFee
			// ------------------------------------------------------------------------
			jsValue = f.GLSSellRateCodFee.value;

			if (trim(jsValue) != ''){

				if (!CheckCur(jsValue)){
					window.location.hash = "#GLSShipmentCharges";
					f.GLSSellRateCodFee.focus();
					return;
				}
			}


//END Added Validation 01152004

			// ------------------------------------------------------------------------
			// Validate GLSBillCompany
			// ------------------------------------------------------------------------
			jsValue = f.GLSBillCompany.value;
			if (trim(jsValue) == ''){
				alert('Please enter a value for the Billing Information Bill To Company.');
				window.location.hash = "#GLSBillingInfo";
				f.GLSBillCompany.focus();
				return;
			}

			// ------------------------------------------------------------------------
			// Validate GLSBillAddress
			// ------------------------------------------------------------------------
			jsValue = f.GLSBillAddress.value;
			if (trim(jsValue) == ''){
				alert('Please enter a value for the Billing Information Bill To Address.');
				window.location.hash = "#GLSBillingInfo";
				f.GLSBillAddress.focus();
				return;
			}

			// ------------------------------------------------------------------------
			// Validate GLSBillAddress
			// ------------------------------------------------------------------------
			jsValue = f.GLSBillCity.value;
			if (trim(jsValue) == ''){
				alert('Please enter a value for the Billing Information Bill To City.');
				window.location.hash = "#GLSBillingInfo";
				f.GLSBillCity.focus();
				return;
			}

			// ------------------------------------------------------------------------
			// Validate GLSBillStateId
			// ------------------------------------------------------------------------
			jsValue = f.GLSBillStateId.selectecIndex;
			if (jsValue == 0){
				alert('Please enter a value for the Billing Information Bill To State.');
				window.location.hash = "#GLSBillingInfo";
				f.GLSBillStateId.focus();
				return;
			}

			// ------------------------------------------------------------------------
			// Validate GLSBillPostalCode
			// ------------------------------------------------------------------------
			jsValue = f.GLSBillPostalCode.value;
			if (trim(jsValue) == ''){
				alert('Please enter a value for the Billing Information Bill To Postal Code.');
				window.location.hash = "#GLSBillingInfo";
				f.GLSBillPostalCode.focus();
				return;
			}

			// ------------------------------------------------------------------------
			// Validate GLSBillCountryId
			// ------------------------------------------------------------------------
			jsValue = f.GLSBillCountryId.selectecIndex;
			if (jsValue == 0){
				alert('Please enter a value for the Billing Information Bill To Country.');
				window.location.hash = "#GLSBillingInfo";
				f.GLSBillCountryId.focus();
				return;
			}

		}//if (jsStatus.toUpperCase() == "SUP")

		f.Submitted.value = "2";
		f.submit();
	}

	function ShowHelp(n){
		var parm1 = "?HelpId=" + n;
		var parm2 = ""
		var parm3 = "";
		var parms = "ShowHelp.asp" + parm1
		var WinAttr = "resizable=yes,scrollbars,menubar=no,toolbars=no,width=400,height=350 top=20 left=20";
		var winh1 =window.open(parms,"ShowHelp",WinAttr);
		winh1.focus();
	}

	function SelectLocation(n,jsPickupRequestTypeWarehouse){
		var f = document.frmAddEdit;
		var parm1 = "?DataType=" + n;
		var parm2 = "&amp;PickupRequestTypeWarehouse=" + jsPickupRequestTypeWarehouse;
		var parm3 = "";
		var parms = "UserLocationPop.asp" + parm1 + parm2
		var WinAttr = "resizable=yes,scrollbars,menubar=no,toolbars=no,width=420,height=500 top=2";
		var win1 =window.open(parms,"GetLocation",WinAttr);
		//var win1 =window.open(parms,"GetLocation");
		win1.focus();
	}

	function SelectLocationI(n,jsPickupRequestTypeWarehouse){
		var f = document.frmAddEdit;
		var parm1 = "?DataType=" + n;
		var parm2 = "&amp;PickupRequestTypeWarehouse=" + jsPickupRequestTypeWarehouse;
		var parm3 = "";
		var parms = "UserLocationPopI.asp" + parm1 + parm2
		var WinAttr = "resizable=yes,scrollbars,menubar=no,toolbars=no,width=420,height=500 top=2";
		//var WinAttr = "status=yes,resizable=yes,scrollbars,menubar=yes,toolbars=yes,width=420,height=500 top=2";
		var win1 =window.open(parms,"GetLocation",WinAttr);
		win1.focus();
	}

	// ------------------------------------------------------------------------
	// Get Warehouse Locations
	// ------------------------------------------------------------------------
	function SelectWarehouseLocation(n,jsPickupRequestType,jsPickupRequestTypeWarehouse){
		var f = document.frmAddEdit;
		var parm1 = "?DataType=" + n;
		var parm2 = "&amp;PickupRequestType=" + jsPickupRequestType;
		var parm3 = "&amp;PickupRequestTypeWarehouse=" + jsPickupRequestTypeWarehouse;
		var parms = "UserLocationWarehousePop.asp" + parm1 + parm2 + parm3
		var WinAttr = "resizable=yes,scrollbars,menubar=no,toolbars=no,width=420,height=500 top=2";
		//var win1 =window.open(parms,"GetLocation");
		var win1 =window.open(parms,"GetLocation",WinAttr);
		win1.focus();
	}


	function SelectCarrier(n){
		var f = document.frmAddEdit;
		var parm1 = "?DataType=" + n
		var parm2 = "";
		var parms = "CarriersPop.asp" + parm1
		var WinAttr = "resizable=yes,scrollbars,menubar=no,toolbars=no,width=420,height=500 top=2";
		var win1 =window.open(parms,"GetLocation",WinAttr);
		win1.focus();
	}


	function AutoFillPop(n){
		var f = document.frmAddEdit;
		var parm1 = "";
		var parms = "AutofillDomesticPop.asp" + parm1
		var WinAttr = "resizable=yes,scrollbars=yes,menubar=no,toolbars=no,width=600,height=600 top=2";
		var win1 =window.open(parms,"GetLocation",WinAttr);
//		var win1 =window.open(parms,"GetLocation");

		win1.focus();
	}

// ------------------------------------------------------------------------
// Skid and Shipment Items Validation
// ------------------------------------------------------------------------

	function AddSkid(jsid,jsPickupRequestType,jsPickupRequestTypeWarehouse,jsWarehouseShipFromLocationId){
		var parm1 = "?pickuprequestid=" + jsid;
		var parm2 = "&amp;PickupRequestType=" + jsPickupRequestType;
		var parm3 = "&amp;PickupRequestTypeWarehouse=" + jsPickupRequestTypeWarehouse;
		var parm4 = "&amp;WarehouseShipFromLocationId=" + jsWarehouseShipFromLocationId;

		var parms = "AddSkidPop.asp" + parm1 + parm2 + parm3 + parm4
		var WinAttr = "resizable=yes,scrollbars,menubar=no,toolbars=no,width=600,height=450 top=2";
		var win1 =window.open(parms,"GetLocation",WinAttr);
		//var win1 =window.open(parms,"GetLocation");
		win1.focus();
	}

	function EditSkid(jsPickupRequestId,jsSkidId,jsPickupRequestType,jsPickupRequestTypeWarehouse,jsWarehouseShipFromLocationId){
		var parm1 = "?PickupRequestId=" + jsPickupRequestId
		var parm2 = "&amp;skidid=" + jsSkidId;
		var parm3 = "&amp;PickupRequestType=" + jsPickupRequestType;
		var parm4 = "&amp;PickupRequestTypeWarehouse=" + jsPickupRequestTypeWarehouse;
		var parm5 = "&amp;WarehouseShipFromLocationId=" + jsWarehouseShipFromLocationId;

		var parms = "AddSkidPop.asp" + parm1 + parm2 + parm3 + parm4 + parm5
		var WinAttr = "resizable=yes,scrollbars,menubar=no,toolbars=no,width=600,height=450 top=2";
		var win1 =window.open(parms,"GetLocation",WinAttr);
		//var win1 =window.open(parms,"GetLocation");
		win1.focus();
	}

	function DeleteSkid(jsSkidId){
	  var f = document.frmdeleteskid;
	  var msg = "";
	  var msg = msg + "     * * * * * *   W A R N I N G    * * * * * *    \n\n";
	  var msg = msg + "You are about to permanently delete this handling unit and its related items          \n";
	  var msg = msg + "from the database. This action                \n";
	  var msg = msg + "can not be undone.                                 \n\n";
	  var msg = msg + "Press OK to continue otherwise press Cancel.       \n";
	  if(confirm(msg)){
	    f.DeleteSkidId.value = jsSkidId;
	    f.submit();
	  }
	}

	function AddShipmentItem(jsPickupRequestId,jsSkidId,jsPickupRequestTypeWarehouse,jsWarehouseShipFromLocationId,jsPickupRequestType){
		var parm1 = "?PickupRequestId=" + jsPickupRequestId
		var parm2 = "&amp;SkidId=" + jsSkidId;
		var parm3 = "&amp;PickupRequestType=" + jsPickupRequestType;
		var parm4 = "&amp;WarehouseShipFromLocationId=" + jsWarehouseShipFromLocationId;

		if(jsPickupRequestTypeWarehouse == 2 || jsPickupRequestTypeWarehouse == 3){
		 var parms = "WarehouseChooserPop.asp" + parm1 + parm2 + parm3 + parm4
		}
		else
		{
		 var parms = "AddShipmentItemsPop.asp" + parm1 + parm2 + parm3
		}
		var WinAttr = "resizable=yes,scrollbars,menubar=no,toolbars=no,width=600,height=450 top=2";
		var win1 = window.open(parms,"GetLocation",WinAttr);
		//var win1 = window.open(parms,"GetLocation");
		win1.focus();
	}
	
	function EditShipmentItem(jsPickupRequestId,jsSkidId,jsShipmentItemId,jsPickupRequestTypeWarehouse,jsWarehouseShipFromLocationId,jsPickupRequestType){
		var parm1 = "?PickupRequestId=" + jsPickupRequestId
		var parm2 = "&amp;SkidId=" + jsSkidId;
		var parm3 = "&amp;ShipmentItemId=" + jsShipmentItemId;
		var parm4 = "&amp;PickupRequestType=" + jsPickupRequestType;
		var parm5 = "&amp;WarehouseShipFromLocationId=" + jsWarehouseShipFromLocationId;

		if(jsPickupRequestTypeWarehouse == 2 || jsPickupRequestTypeWarehouse == 3){
		 var parms = "AddShipmentItemsWarehousePop.asp" + parm1 + parm2 + parm3 + parm4 + parm5
		}
		else
		{
		 var parms = "AddShipmentItemsPop.asp" + parm1 + parm2 + parm3 + parm4
		}
		var WinAttr = "resizable=yes,scrollbars,menubar=no,toolbars=no,width=600,height=450 top=2";
		var win1 = window.open(parms,"GetLocation",WinAttr);
		//var win1 = window.open(parms,"GetLocation");
		win1.focus();
	}


	function DeleteShipmentItem(jsShipmentItemId){
	  var f = document.frmdeleteshipmentitem;
	  var msg = "";
	  var msg = msg + "     * * * * * *   W A R N I N G    * * * * * *    \n\n";
	  var msg = msg + "You are about to permanently delete this Shipmet Item           \n";
	  var msg = msg + "from the database. This action                \n";
	  var msg = msg + "can not be undone.                                 \n\n";
	  var msg = msg + "Press OK to continue otherwise press Cancel.       \n";
	  if(confirm(msg)){
	    f.DeleteShipmentItemId.value = jsShipmentItemId;
	    f.submit();
	  }
	}

