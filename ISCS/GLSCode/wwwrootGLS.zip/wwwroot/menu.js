
//  QuickMenu Pro, Copyright (c) - 2002, OpenCube Inc. - http://www.opencube.com
//  
//
//
//  QuickMenu Pro - (QuickMenu v3.0) Works With....
//
//      IE4, IE5.x, IE6 (Win 95, 98, ME, 2000, NT, XP)
//      IE4, IE5.x, &up (Mac)
//      NS4.x (All Platforms)
//      NS5/6.x (All Platforms)
//      ns7 - beta (All Platforms)
//      Opera 5 & 6 (All Platforms)
//      Mozilla 1.0 & up
//
//  


/*-------------------------------------------
Copyright Notice - The following parameter is 
required in order for the menu to function.
--------------------------------------------*/


   DQM_Notice = "DHTML QuickMenu, Copyright (c) - 2002, OpenCube Inc. - www.opencube.com"
 

   limit_multiple_users = true

/*-------------------------------------------
required menu Settings
--------------------------------------------*/


   DQM_sub_menu_width = 130      //default sub menu widths
   DQM_sub_xy = "0,0"            //default sub x,y coordinates
   
   
   DQM_codebase = ""             //relative location of .js files
   DQM_urltarget = "_self"       //set to: _self, _parent, _new, or "my frame name"

   DQM_border_width = 1
   DQM_divider_height = 1

   DQM_border_color = "#59060A"  //Hex color value or 'transparent'
   DQM_menu_bgcolor = "#985558"  //Hex color value or 'transparent'
   DQM_hl_bgcolor = "#C2C2C2"    //Hex color value


   DQM_mouse_off_delay = 500
   
   
   DQM_os9_ie5mac_offset_X = 10
   DQM_os9_ie5mac_offset_Y = 15

   DQM_osx_ie5mac_offset_X = 0
   DQM_osx_ie5mac_offset_Y = 0

   DQM_ie4mac_offset_X = -8
   DQM_ie4mac_offset_Y = -50
   
   DQM_nn4_reaload_after_resize = true

   DQM_nn4_resize_prompt_user = false
   DQM_nn4_resize_prompt_message = "To reinitialize the navigation menu please click the 'Reload' button."
   

   DQM_use_opera_div_detect_fix = true;


/*-------------------------------------------
Internet Explorer Transition Effects - IE5.5 & UP

Note: All non supporting browsers will ignore
the effect settings below while retaining the
complete sub menu functionality and look.
--------------------------------------------*/

	
   /*----Options include - none | fade | pixelate |
   ------iris | slide | gradientwipe | checkerboard |
   ------radialwipe | randombars | randomdissolve |stretch */

   DQM_sub_menu_effect = "none"
   DQM_sub_item_effect = "none"


   /*----Define the effect duration in seconds below---*/
   
   DQM_sub_menu_effect_duration = .4
   DQM_sub_item_effect_duration = .4

  
   /*----Customization option settings for the various effect
   ------transitions may be defined below---*/

   DQM_effect_pixelate_maxsqare = 25
   DQM_effect_iris_irisstyle = "CIRCLE"          //CROSS, CIRCLE, PLUS, SQUARE, or STAR
   DQM_effect_checkerboard_squaresx = 14
   DQM_effect_checkerboard_squaresY = 14
   DQM_effect_checkerboard_direction = "RIGHT"   //UP, DOWN, LEFT, RIGHT
   

   DQM_sub_menu_opacity = 100

   DQM_dropshadow_color = "none"                //Hex color value or 'none'
   DQM_dropshadow_offx = 5                      //drop shadow width
   DQM_dropshadow_offy = 5	                //drop shadow height

/*-------------------------------------------
Required font Settings
--------------------------------------------*/
   

   DQM_textcolor = "#ffffff"
   DQM_fontfamily = "Verdana"            //Any available system font     
   DQM_fontsize = 11		         //Defined with pixel sizing  	
   DQM_fontsize_ie4 = 9		         //Defined with point sizing
   DQM_textdecoration = "normal"         //set to: 'normal', or 'underline'
   DQM_fontweight = "normal"             //set to: 'normal', or 'bold'
   DQM_fontstyle = "normal"	         //set to: 'normal', or 'italic' 	
   DQM_hl_textcolor = "#002055"
   DQM_hl_textdecoration = "normal"   //set to: 'normal', or 'underline'

   DQM_margin_top = 0
   DQM_margin_bottom = 2
   DQM_margin_left = 5
   DQM_margin_right = 4

   DQM_text_alignment = "left"           //set to: 'left', 'center' or 'right'
   
   DQM_show_urls_statusbar = false
   

/*********************************************************************/
/*                                                                   */
/*                       MAIN MENU CUSTOMIZATION                     */
/*                                                                   */ 
/*********************************************************************/

   DQM_rollover_image0 = "images/menu/Home-over.gif"
   DQM_rollover_wh0 = "124,17"
   DQM_url0 = "Default.asp";

   DQM_rollover_image1 = "images/menu/Company-over.gif"
   DQM_rollover_wh1 = "124,17"
   DQM_url1 = "Company.asp";   

   DQM_rollover_image2 = "images/menu/Solutions-over.gif"
   DQM_rollover_wh2 = "124,17"
   DQM_url2 = "Solutions.asp";  

   DQM_rollover_image3 = "images/menu/ContactUs-over.gif" 
   DQM_rollover_wh3 = "124,17"
   DQM_url3 = "Contact.asp";   

   DQM_rollover_image4 = "images/menu/News-over.gif" 
   DQM_rollover_wh4 = "124,17"
   DQM_url4 = "News.asp";
   
   DQM_rollover_image5 = "images/menu/AirportCodes-over.gif" 
   DQM_rollover_wh5 = "124,17"
   DQM_url5 = "AirportCodes.asp";

   DQM_rollover_image6 = "images/menu/SiteMap-over.gif" 
   DQM_rollover_wh6 = "124,17"
   DQM_url6 = "SiteMap.asp";    
   
   DQM_rollover_image7 = "images/menu/Login-over.gif" 
   DQM_rollover_wh7 = "124,17"
   DQM_url7 = "PasswordCheck.asp";   
    
     


/*********************************************************************/
/*                                                                   */
/*                       SUB MENU CUSTOMIZATION                      */
/*                                                                   */ 
/*********************************************************************/

/******************  HOME  *******************/
/** 0 **/

/******************  COMPANY  *******************/
DQM_sub_xy1 = "0,0"
DQM_sub_menu_width1 = 120
DQM_subdesc1_0 = "Company Profile"
DQM_subdesc1_1 = "Key Management"
DQM_subdesc1_2 = "Mission"
DQM_subdesc1_3 = "Testimonials"
DQM_subdesc1_4 = "GLS Presentation"
DQM_url1_0 = "Company.asp"
DQM_url1_1 = "KeyManagement.asp"
DQM_url1_2 = "Mission.asp"
DQM_url1_3 = "Testimonials.asp"
DQM_url1_4 = "GLSPresentation.asp"

/******************  SOLUTIONS  *******************/
DQM_sub_xy2 = "0,0"
DQM_sub_menu_width2 = 140
DQM_subdesc2_0 = "Logistics Solutions"
DQM_subdesc2_1 = "eCommerce"
DQM_subdesc2_2 = "Value Added Services"
DQM_url2_0 = "Solutions.asp"
DQM_url2_1 = "eCommerce.asp"
DQM_url2_2 = "valueservices.asp"


/******************  CONTACT US  *******************/
DQM_sub_xy3 = "0,0"
DQM_sub_menu_width3 = 100
DQM_subdesc3_0 = "Contact Info"
DQM_subdesc3_1 = "Feedback"
DQM_subdesc3_2 = "Info Request"
DQM_subdesc3_3 = "Take a Survey"
DQM_url3_0 = "Contact.asp"
DQM_url3_1 = "Feedback.asp"
DQM_url3_2 = "InfoRequest.asp"
DQM_url3_3 = "TakeASurvey.asp"


/******************  NEWS  *******************/
DQM_sub_xy4 = "0,0"
DQM_sub_menu_width4 = 150
DQM_subdesc4_0 = "Web Site Changes"
DQM_subdesc4_1 = "Media Coverage"
DQM_subdesc4_2 = "Industry Trends"
DQM_url4_0 = "NewsWebsiteChanges.asp"
DQM_url4_1 = "NewsMediaCoverage.asp"
DQM_url4_2 = "NewsIndustryTrends.asp"

/******************  AIRPORT CODES  *******************/
DQM_sub_xy5 = "0,0"
DQM_sub_menu_width5 = 130
DQM_subdesc5_0 = "Domestic Codes"
DQM_subdesc5_1 = "International Codes"
DQM_url5_0 = "CodesDomestic.asp"
DQM_url5_1 = "CodesInternational.asp"

/******************  SITE MAP  *******************/
/** 7 **/

/******************  SECURE LOGON  *******************/
DQM_sub_xy7 = "0,0"
DQM_sub_menu_width7 = 150
DQM_subdesc7_0 = "Secure Login"
DQM_subdesc7_1 = "Register for an Account"
DQM_subdesc7_2 = "Forgot Password"
DQM_url7_0 = "PasswordCheck.asp"
DQM_url7_1 = "Register.asp"
DQM_url7_2 = "ForgotPass.asp"

